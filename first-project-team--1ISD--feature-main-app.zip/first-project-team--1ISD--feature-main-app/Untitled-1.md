git clone https://github.com/Closi1/first-project-team--1ISD-.git
cd first-project-team--1ISD-
git config --global user.name "Closi1"
git config --global user.email "Closimake@gmail.com"

echo "print('Hello, GitHub!')" > hello.py
git add .
git commit -m "Initial commit: add hello.py"
git push origin main




